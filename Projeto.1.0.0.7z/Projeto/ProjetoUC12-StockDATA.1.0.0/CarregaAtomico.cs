﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoUC12_StockDATA
{
    public class CarregaAtomico
    {
        public string dadocA;
        public SqlConnection conn = new SqlConnection(Variaveis.strConn);
        //CarregaComboBox concatenando duas colunas especificadas
        public List<string> carregaComboBoxComposto(string SQL, string coluna, string coluna2)
        {
            List<string> Item = new List<string>();
            try
            {
                conn.Open();
                SqlCommand consulta = new SqlCommand(SQL, conn);
                // Criar o DataReader:
                SqlDataReader drDados = null;
                // Executar a consulta:
                drDados = consulta.ExecuteReader();
                if (drDados.HasRows) // Verificar se há linhas retornadas
                {
                    while (drDados.Read())
                    {
                        Item.Add(drDados[coluna].ToString() + " " + drDados[coluna2].ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Registros não encontrados");
                }
                drDados.Close();
                conn.Close();
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Source.ToString());
            }
            return Item;
        }
        //CarregaComboBox com somento uma coluna
        public List<string> carregaComboBox(string SQL, string coluna)
        {
            List<string> Item = new List<string>();
            try
            {
                conn.Open();
                // Criar comando de consulta:
                SqlCommand consulta = new SqlCommand(SQL, conn);
                // Criar o DataReader:
                SqlDataReader drDados = null;
                // Executar a consulta:
                drDados = consulta.ExecuteReader();
                if (drDados.HasRows) // Verificar se há linhas retornadas
                {
                    while (drDados.Read())
                    {
                        Item.Add(drDados[coluna].ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Registros não encontrados");
                }
                drDados.Close();
                conn.Close();
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Source.ToString());
            }
            return Item;
        }
        //Retorna uma somente linha de uma coluna especificada de uma consulta (variavel de resultado: dadocA em string)
        public void consultaAtomica(string SQLconsulta, string coluna)
        {
            conn.Open();
            SqlCommand comando = new SqlCommand(SQLconsulta, conn);
            SqlDataReader drDados = null;
            drDados = comando.ExecuteReader();
            if (drDados.HasRows)
            {
                while (drDados.Read())
                {
                    dadocA = drDados[coluna].ToString();
                }
            }
            else
            {
                MessageBox.Show("Código não encontrado");
            }
            drDados.Close();
            conn.Close();
        }
    }
}
