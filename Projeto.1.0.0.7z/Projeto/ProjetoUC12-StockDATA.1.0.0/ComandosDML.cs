﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoUC12_StockDATA
{
    class ComandosDML
    {
        // Método para inserir, atualizar ou excluir registros:
        //DML significa Data Manipulation Language
        public void iud(string sql)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}