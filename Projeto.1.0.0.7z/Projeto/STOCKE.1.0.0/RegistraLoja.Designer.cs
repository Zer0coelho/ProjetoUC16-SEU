﻿namespace STOCKE
{
    partial class RegistraLoja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCNPJ = new System.Windows.Forms.TextBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtCelular = new System.Windows.Forms.TextBox();
            this.txtRepSenha = new System.Windows.Forms.TextBox();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnProximo = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picLoja = new System.Windows.Forms.PictureBox();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.txtRua = new System.Windows.Forms.TextBox();
            this.txtComplemento = new System.Windows.Forms.TextBox();
            this.txtCep = new System.Windows.Forms.TextBox();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.cmbEstado = new System.Windows.Forms.ComboBox();
            this.btnCadastra = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLoja)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCNPJ
            // 
            this.txtCNPJ.BackColor = System.Drawing.Color.Lime;
            this.txtCNPJ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCNPJ.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCNPJ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtCNPJ.Location = new System.Drawing.Point(847, 412);
            this.txtCNPJ.Name = "txtCNPJ";
            this.txtCNPJ.Size = new System.Drawing.Size(259, 32);
            this.txtCNPJ.TabIndex = 0;
            // 
            // txtSenha
            // 
            this.txtSenha.BackColor = System.Drawing.Color.Lime;
            this.txtSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSenha.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtSenha.Location = new System.Drawing.Point(847, 528);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.PasswordChar = '*';
            this.txtSenha.Size = new System.Drawing.Size(259, 32);
            this.txtSenha.TabIndex = 0;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.Lime;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtEmail.Location = new System.Drawing.Point(847, 471);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(259, 32);
            this.txtEmail.TabIndex = 0;
            // 
            // txtCelular
            // 
            this.txtCelular.BackColor = System.Drawing.Color.Lime;
            this.txtCelular.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCelular.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCelular.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtCelular.Location = new System.Drawing.Point(1311, 408);
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.Size = new System.Drawing.Size(259, 32);
            this.txtCelular.TabIndex = 0;
            // 
            // txtRepSenha
            // 
            this.txtRepSenha.BackColor = System.Drawing.Color.Lime;
            this.txtRepSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRepSenha.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRepSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtRepSenha.Location = new System.Drawing.Point(1311, 523);
            this.txtRepSenha.Name = "txtRepSenha";
            this.txtRepSenha.PasswordChar = '*';
            this.txtRepSenha.Size = new System.Drawing.Size(259, 32);
            this.txtRepSenha.TabIndex = 0;
            // 
            // txtTelefone
            // 
            this.txtTelefone.BackColor = System.Drawing.Color.Lime;
            this.txtTelefone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelefone.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtTelefone.Location = new System.Drawing.Point(1311, 465);
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(259, 32);
            this.txtTelefone.TabIndex = 0;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnProximo
            // 
            this.btnProximo.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnProximo.BackColor = System.Drawing.Color.Transparent;
            this.btnProximo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnProximo.FlatAppearance.BorderSize = 0;
            this.btnProximo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnProximo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnProximo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProximo.Location = new System.Drawing.Point(1292, 669);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(278, 51);
            this.btnProximo.TabIndex = 3;
            this.btnProximo.Text = "proximo";
            this.btnProximo.UseVisualStyleBackColor = false;
            this.btnProximo.Click += new System.EventHandler(this.btnProximo_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.cmbEstado);
            this.panel1.Controls.Add(this.txtBairro);
            this.panel1.Controls.Add(this.txtRua);
            this.panel1.Controls.Add(this.txtComplemento);
            this.panel1.Controls.Add(this.txtCep);
            this.panel1.Controls.Add(this.txtNumero);
            this.panel1.Location = new System.Drawing.Point(705, 380);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(897, 231);
            this.panel1.TabIndex = 4;
            this.panel1.Visible = false;
            // 
            // picLoja
            // 
            this.picLoja.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.picLoja.Location = new System.Drawing.Point(1181, 104);
            this.picLoja.Name = "picLoja";
            this.picLoja.Size = new System.Drawing.Size(408, 198);
            this.picLoja.TabIndex = 2;
            this.picLoja.TabStop = false;
            this.picLoja.Click += new System.EventHandler(this.picLoja_Click);
            // 
            // txtBairro
            // 
            this.txtBairro.BackColor = System.Drawing.Color.Lime;
            this.txtBairro.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBairro.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBairro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtBairro.Location = new System.Drawing.Point(587, 85);
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(278, 32);
            this.txtBairro.TabIndex = 1;
            // 
            // txtRua
            // 
            this.txtRua.BackColor = System.Drawing.Color.Lime;
            this.txtRua.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRua.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRua.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtRua.Location = new System.Drawing.Point(115, 91);
            this.txtRua.Name = "txtRua";
            this.txtRua.Size = new System.Drawing.Size(286, 32);
            this.txtRua.TabIndex = 2;
            // 
            // txtComplemento
            // 
            this.txtComplemento.BackColor = System.Drawing.Color.Lime;
            this.txtComplemento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtComplemento.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComplemento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtComplemento.Location = new System.Drawing.Point(703, 143);
            this.txtComplemento.Name = "txtComplemento";
            this.txtComplemento.PasswordChar = '*';
            this.txtComplemento.Size = new System.Drawing.Size(162, 32);
            this.txtComplemento.TabIndex = 3;
            // 
            // txtCep
            // 
            this.txtCep.BackColor = System.Drawing.Color.Lime;
            this.txtCep.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCep.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCep.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtCep.Location = new System.Drawing.Point(525, 28);
            this.txtCep.Name = "txtCep";
            this.txtCep.Size = new System.Drawing.Size(340, 32);
            this.txtCep.TabIndex = 4;
            // 
            // txtNumero
            // 
            this.txtNumero.BackColor = System.Drawing.Color.Lime;
            this.txtNumero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumero.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumero.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.txtNumero.Location = new System.Drawing.Point(181, 148);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.PasswordChar = '*';
            this.txtNumero.Size = new System.Drawing.Size(220, 32);
            this.txtNumero.TabIndex = 5;
            // 
            // cmbEstado
            // 
            this.cmbEstado.BackColor = System.Drawing.Color.Lime;
            this.cmbEstado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbEstado.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEstado.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbEstado.FormattingEnabled = true;
            this.cmbEstado.Location = new System.Drawing.Point(165, 28);
            this.cmbEstado.Name = "cmbEstado";
            this.cmbEstado.Size = new System.Drawing.Size(236, 40);
            this.cmbEstado.TabIndex = 6;
            this.cmbEstado.SelectedIndexChanged += new System.EventHandler(this.cmbEstado_SelectedIndexChanged);
            // 
            // btnCadastra
            // 
            this.btnCadastra.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCadastra.BackColor = System.Drawing.Color.Transparent;
            this.btnCadastra.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCadastra.FlatAppearance.BorderSize = 0;
            this.btnCadastra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCadastra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCadastra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastra.Location = new System.Drawing.Point(1311, 669);
            this.btnCadastra.Name = "btnCadastra";
            this.btnCadastra.Size = new System.Drawing.Size(278, 51);
            this.btnCadastra.TabIndex = 5;
            this.btnCadastra.Text = "finaliza";
            this.btnCadastra.UseVisualStyleBackColor = false;
            this.btnCadastra.Visible = false;
            this.btnCadastra.Click += new System.EventHandler(this.btnCadastra_Click);
            // 
            // RegistraLoja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::STOCKE.Properties.Resources.Registre_se_LOJA;
            this.ClientSize = new System.Drawing.Size(1742, 789);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.picLoja);
            this.Controls.Add(this.txtTelefone);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtRepSenha);
            this.Controls.Add(this.txtCelular);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.txtCNPJ);
            this.Controls.Add(this.btnCadastra);
            this.Name = "RegistraLoja";
            this.Text = "RegistraLoja";
            this.Load += new System.EventHandler(this.RegistraLoja_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLoja)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCNPJ;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtCelular;
        private System.Windows.Forms.TextBox txtRepSenha;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.PictureBox picLoja;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnProximo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtBairro;
        private System.Windows.Forms.TextBox txtRua;
        private System.Windows.Forms.TextBox txtComplemento;
        private System.Windows.Forms.TextBox txtCep;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.ComboBox cmbEstado;
        private System.Windows.Forms.Button btnCadastra;
    }
}