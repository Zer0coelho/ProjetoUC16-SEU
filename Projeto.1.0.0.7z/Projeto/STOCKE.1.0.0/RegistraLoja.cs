﻿using STOCKE.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOCKE
{
    public partial class RegistraLoja : Form
    {
        public string consulta;
        public string sql;
        public string caminhoImagem;
        public RegistraLoja()
        {
            InitializeComponent();
        }

        private void RegistraLoja_Load(object sender, EventArgs e)
        {

        }

        private void picLoja_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            caminhoImagem = openFileDialog1.FileName;
            picLoja.ImageLocation = caminhoImagem;
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            btnProximo.Visible = false;
            btnCadastra.Visible = true;
            panel1.Visible = true;
            this.BackgroundImage = Properties.Resources.Registre_se_LOJA_2;
        }

        private void btnCadastra_Click(object sender, EventArgs e)
        {

        }

        private void cmbEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Carrega ComboBox com método da classe CarregaComboBox e Lista:
            consulta = "SELECT Estado FROM tbl_estados;";
            //CarregaComboBox carregaEstado = new CarregaComboBox();

            //Criar objeto de lista para armazenar os dados dos livros:
            List<string> Estado = new List<string>();
            Estado.AddRange(carregaEstado.carregaComboBoxEstado(consulta, "Estado"));

            //Copia dados da lsita para o ComboBox:
            cmbEstado.Items.AddRange(Estado.ToArray());
        }
    }
}
