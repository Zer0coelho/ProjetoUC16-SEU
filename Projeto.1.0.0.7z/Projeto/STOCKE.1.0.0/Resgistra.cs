﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOCKE
{
    public partial class Registra : Form
    {
        public Registra()
        {
            InitializeComponent();
        }

        /*private void button1_Click(object sender, EventArgs e)
        {
            RegistraLoja registraLoja = new RegistraLoja();
            registraLoja.Show();
            this.Close();
            

        }*/

        private void btnregiLoja_Click(object sender, EventArgs e)
        {
            RegistraLoja registraLoja = new RegistraLoja();
            registraLoja.Show();
            this.Close();
        }
    }
}
