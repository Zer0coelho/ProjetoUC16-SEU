﻿namespace STOCKE
{
    partial class Registra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnregiLoja = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnregiLoja
            // 
            this.btnregiLoja.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnregiLoja.BackColor = System.Drawing.Color.Transparent;
            this.btnregiLoja.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnregiLoja.FlatAppearance.BorderSize = 0;
            this.btnregiLoja.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnregiLoja.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnregiLoja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnregiLoja.Location = new System.Drawing.Point(335, 401);
            this.btnregiLoja.Name = "btnregiLoja";
            this.btnregiLoja.Size = new System.Drawing.Size(322, 51);
            this.btnregiLoja.TabIndex = 2;
            this.btnregiLoja.Text = "button1";
            this.btnregiLoja.UseVisualStyleBackColor = false;
            this.btnregiLoja.Click += new System.EventHandler(this.btnregiLoja_Click);
            // 
            // Registra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::STOCKE.Properties.Resources.Registre_se;
            this.ClientSize = new System.Drawing.Size(1372, 667);
            this.Controls.Add(this.btnregiLoja);
            this.Name = "Registra";
            this.Text = "Resgistra";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnregiLoja;
    }
}