﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoUC12_StockDATA
{
    public partial class CadastraLoja1 : Form
    {
        public string sql;
        public string consulta;
        string ID_Estado;
        public string caminhoImagem;
        CarregaAtomico carregaAtomico = new CarregaAtomico();
        public CadastraLoja1()
        {
            InitializeComponent();
        }
        private void txtCep_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRua_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBairro_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCadastra_Click(object sender, EventArgs e)
        {
            //Criptografar senha
            if (txtSenha.Text.Equals(txtRepSenha.Text))
            {
                Criptografar cripto = new Criptografar();
                string senha = cripto.HashSHA256(txtSenha.Text);

                //Criar string SQL:
                string sql = "INSERT INTO tbl_loja(CNPJ, Nome_Loja, imagem, Senha, Rua, Numero, Bairro, Complemento, Cep, Email, Celular, Telefone, ID_Estado)" +
                    " VALUES ('" + mtxtCNPJ.Text + "','" + txtNomeLoja.Text + "','" + caminhoImagem + "','" + senha + "','" + txtRua.Text + "','" + txtNumero.Text + "','" + txtBairro.Text + "'," + txtComplemento.Text + "'," + txtCep.Text + "'," + txtEmail.Text + "'," + txtCelular + "'," + txtTelefone.Text + "'," + ID_Estado + ")";
                //MessageBox.Show(sql);
                ComandosDML inserir = new ComandosDML();
                try
                {
                    inserir.iud(sql);
                    MessageBox.Show("Loja Cadastrada");
                }
                catch (SqlException s)
                {
                    MessageBox.Show(s.Source.ToString());
                }
            }
            else
            {
                MessageBox.Show("As senha digitadas não correspondem", "Senha inválida");
            }
        }

        private void btnMostraSenha_Click(object sender, EventArgs e)
        {
            if (txtSenha.PasswordChar == '*')
            {
                txtSenha.PasswordChar = '\0';
                txtRepSenha.PasswordChar = '\0';
                btnMostraSenha.Text = "Oculta Senha";
            }
            else
            {
                txtSenha.PasswordChar = '*';
                txtRepSenha.PasswordChar = '*';
                btnMostraSenha.Text = "Exibir Senha";
            }
        }

        private void mtxtCNPJ_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void cmbEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            string consulta = "SELECT ID_Estado FROM tbl_Estados WHERE Estado = '" + cmbEstado.SelectedItem.ToString() + "'";
            carregaAtomico.consultaAtomica(consulta, "ID_Estado");
            ID_Estado = carregaAtomico.dadocA;
            //MessageBox.Show(ID_Estado, "ID de ESTADO");
        }

        private void CadastraLoja1_Load(object sender, EventArgs e)
        {
            //Carrega ComboBox com método da classe CarregaComboBox e Lista:
            consulta = "SELECT Estado FROM tbl_estados;";
            

            //Criar objeto de lista para armazenar os dados dos livros:
            List<string> Estado = new List<string>();
            Estado.AddRange(carregaAtomico.carregaComboBox(consulta, "Estado"));

            //Copia dados da lsita para o ComboBox:
            cmbEstado.Items.AddRange(Estado.ToArray());
        }

        private void btnSelecImagem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            caminhoImagem = openFileDialog1.FileName;
            picLoja.ImageLocation = caminhoImagem;
        }
    }
}
